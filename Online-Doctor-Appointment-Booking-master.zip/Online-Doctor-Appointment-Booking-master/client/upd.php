<!DOCTYPE html>
<html lang="en-US">
  <head>
  <title>IT SourceCode</title>
  <link rel="stylesheet" href="libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="libs/style.css">
  </head>
  <?php
  include 'db.php';
  include('auth_session.php');
  
$id=$_SESSION['username'];
$query=mysqli_query($con,"SELECT * FROM clientlogin where clientid='$id'")or die(mysqli_error());
$row=mysqli_fetch_array($query);
  ?>
  <h1>User Profile</h1>
<div class="profile-input-field">
        <h3>Please Fill-out All Fields</h3>

        <form method="post" action="#" >

          <div class="form-group">
            <label>clientname</label>
            <input type="text" class="form-control" name="clientname" style="width:20em;" placeholder="Enter your clientname" value="<?php echo $row['clientname']; ?>" required />
          </div>

          <div class="form-group">
            <label>clientpassword</label>
            <input type="text" class="form-control" name="clientpassword" style="width:20em;" placeholder="Enter your clientpassword" value="<?php echo $row['clientpassword']; ?>" required />
          </div>

          <div class="form-group">
            <label>clientemail</label>
            <input type="text" class="form-control" name="clientemail" style="width:20em;" placeholder="Enter your clientemail" value="<?php echo $row['clientemail']; ?>" required />
          </div>

          <div class="form-group">
            <label>phoneno</label>
            <input type="text" class="form-control" name="phoneno" style="width:20em;" placeholder="Enter your phoneno" value="<?php echo $row['phoneno']; ?>" required />
          </div>

          <div class="form-group">
            <label>bloodgroup</label>
            <input type="text" class="form-control" name="bloodgroup" style="width:20em;" placeholder="Enter your bloodgroup" value="<?php echo $row['bloodgroup']; ?>" required />
          </div>

          <div class="form-group">
            <label>address</label>
            <input type="text" class="form-control" name="address" style="width:20em;" placeholder="Enter your address" value="<?php echo $row['address']; ?>" required />
          </div>

          <div class="form-group">
            <label>dob</label>
            <input type="date" class="form-control" name="dob" style="width:20em;" placeholder="Enter your dob" value="<?php echo $row['dob']; ?>" required />
          </div>

          <div class="form-group">
            <label>age</label>
            <input type="text" class="form-control" name="age" style="width:20em;" placeholder="Enter your age" value="<?php echo $row['age']; ?>" required />
          </div>

          <div class="form-group">
            <label>allergy</label>
            <input type="text" class="form-control" name="allergy" style="width:20em;" placeholder="Enter your allergy" value="<?php echo $row['allergy']; ?>" required />
          </div>

          
          <div class="form-group">
            <input type="submit" name="submit" class="btn btn-primary" style="width:20em; margin:0;"><br><br>
            <center>
             <a href="logout.php">Log out</a>
           </center>
          </div>
        </form>
      </div>
      </html>

      <?php
      if(isset($_POST['submit'])){
      $clientname=$_POST['clientname'];
      $clientpassword=$_POST['clientpassword'];
      $clientemail=$_POST['clientemail'];
      $phoneno=$_POST['phoneno'];
      $bloodgroup=$_POST['bloodgroup'];
      $address=$_POST['address'];
      $dob=$_POST['dob'];
      $age = $_POST['age'];
      $allergy = $_POST['allergy'];

      $query = "UPDATE clientlogin SET clientname=:clientname, clientpassword=:clientpassword, clientemail=:clientemail, phoneno=:phoneno, bloodgroup=:bloodgroup, address=:address, dob=:dob, age=:age, allergy=:allergy WHERE id=:id";
                    $result = mysqli_query($con, $query) or die(mysqli_error($con));
                    ?>
                     <script type="text/javascript">
            alert("Update Successfull.");
            window.location = "index.php";
        </script>
        <?php
             }              
?>