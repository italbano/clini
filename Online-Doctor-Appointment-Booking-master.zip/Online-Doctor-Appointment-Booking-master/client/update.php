<!DOCTYPE HTML>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<link href="css/dashboard.css" rel="stylesheet">
	</head>
<body>


<?php


if(isset($_POST['submit']))
	{
			include("header.php");
			include('db.php');
			include("auth_session.php");


			
			$clientname=$_POST['clientname'];
			$clientpassword=$_POST['clientpassword'];
			$clientemail=$_POST['clientemail'];
			$phoneno=$_POST['phoneno'];
			$bloodgroup=$_POST['bloodgroup'];
			$address=$_POST['address'];
			$dob=$_POST['dob'];
			$age = $_POST['age'];
			$allergy = $_POST['allergy'];
		
			


			echo $id=$_SESSION['username'];

		
		$sql = "UPDATE clientlogin SET clientname=:clientname, clientpassword=:clientpassword, clientemail=:clientemail, phoneno=:phoneno, bloodgroup=:bloodgroup, address=:address, dob=:dob, age=:age, allergy=:allergy WHERE id=:id";
		$execute1 = mysqli_query($con,$sql);
		if($execute1)
		{
			?>
			<script>
			alert("updated successfully");
			</script>
			<?php
			
			
		}
		else
		{
			?>
			<script>
		
			alert("Enter data in right format");
			</script>
			
			<?php
		}
		
		
		
		
		
		$sql = "SELECT * FROM `clientlogin` WHERE `clientid`= $id;";
		$execute1 = mysqli_query($con,$sql);
		if($execute1)
		{
			$data = mysqli_fetch_assoc($execute1);
			?><pre><?php
			print_r($data);
			?>
			</pre><?php
		  	$clientname=$data['clientname'];
            $clientpassword=$data['clientpassword'];
            $clientemail=$data['clientemail'];
            $phoneno=$data['phoneno'];
            $bloodgroup=$data['bloodgroup'];
            $address=$data['address'];
            $dob=$data['dob'];
            $age=$data['age'];
            $allergy=$data['allergy'];
}

		
		
	}

?>