
<div id="main-content">
    <h2>Update Record</h2>
    <?php
    include 'db.php';

    include("auth_session.php");
    $id = $_SESSION['clientid'];
    $sql = "SELECT * FROM clientlogin WHERE id = {$id}";
    $result = mysqli_query($con, $sql) or die("Query Unsuccessful.");

    if(mysqli_num_rows($result) > 0)  {
      while($row = mysqli_fetch_assoc($result)){
    ?>
    <form class="post-form" action="updata.php" method="post">

      <div class="form-group">
          <label>clientname</label>
          <input type="text" name="clientname" value="<?php echo $row['clientname']; ?>"/>
      </div>

      <div class="form-group">
          <label>clientpassword</label>
          <input type="text" name="clientpassword" value="<?php echo $row['clientpassword']; ?>"/>
      </div>

     
      <div class="form-group">
          <label>clientemail</label>
          <input type="text" name="clientemail" value="<?php echo $row['clientemail']; ?>"/>
      </div>

      <div class="form-group">
          <label>phoneno</label>
          <input type="text" name="phoneno" value="<?php echo $row['phoneno']; ?>"/>
      </div>

     
      <div class="form-group">
          <label>bloodgroup</label>
          <input type="text" name="bloodgroup" value="<?php echo $row['bloodgroup']; ?>"/>
      </div>

      <div class="form-group">
          <label>address</label>
          <input type="text" name="address" value="<?php echo $row['address']; ?>"/>
      </div>

     
      <div class="form-group">
          <label>dob</label>
          <input type="date" name="dob" value="<?php echo $row['dob']; ?>"/>
      </div>

      <div class="form-group">
          <label>age</label>
          <input type="text" name="age" value="<?php echo $row['age']; ?>"/>
      </di>

      <div class="form-group">
          <label>allergy</label>
          <input type="text" name="allergy" value="<?php echo $row['allergy']; ?>"/>
      </di>
     
      <input class="submit" type="submit" value="Update"/>
    </form>
    <?php
      }
    }
    ?>
</div>
</div>