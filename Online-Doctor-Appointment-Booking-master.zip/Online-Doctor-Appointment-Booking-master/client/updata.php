<?php
			$clientid=$_POST['clientid'];
			$clientname=$_POST['clientname'];
			$clientpassword=$_POST['clientpassword'];
			$clientemail=$_POST['clientemail'];
			$phoneno=$_POST['phoneno'];
			$bloodgroup=$_POST['bloodgroup'];
			$address=$_POST['address'];
			$dob=$_POST['dob'];
			$age = $_POST['age'];
			$allergy = $_POST['allergy'];

include 'db.php';

$sql = "UPDATE clientlogin SET 
clientname = '{$clientname}', 
clientpassword = '{$clientpassword}',
clientemail = '{$clientemail}', 
phoneno = '{$phoneno}',
bloodgroup = '{$bloodgroup}', 
address = '{$address}',
dob = '{$dob}', 
age = '{$age}',
allergy = '{$allergy}'
 WHERE id = {$clientid}";

$result = mysqli_query($con, $sql) or die("Query Unsuccessful.");

header("/dashboard.php");

mysqli_close($con);

?>