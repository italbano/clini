<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'de');
 
/* Attempt to connect to MySQL database */
try{
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
    die("ERROR: Could not connect. " . $e->getMessage());
}

 
// Define variables and initialize with empty values
$clientname = $clientpassword = $clientemail = $phoneno = $bloodgroup = $address = $dob = $age = $allergy = "";
$clientname_err = $clientpassword_err = $clientemail_err = $phoneno_err = $bloodgroup_err = $address_err = $dob_err = $age_err = $allergy_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate name
    $input_clientname = trim($_POST["clientname"]);
    if(empty($input_clientname)){
        $clientname_err = "Please enter a name.";
    } elseif(!filter_var($input_clientname, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $clientname_err = "Please enter a valid name.";
    } else{
        $clientname = $input_clientname;
    }
    
    // Validate address
    $input_clientpassword = trim($_POST["clientpassword"]);
    if(empty($input_clientpassword)){
        $clientpassword_err = "Please enter an address.";     
    } else{
        $clientpassword = $input_clientpassword;
    }

    // Validate address
    $input_clientemail = trim($_POST["clientemail"]);
    if(empty($input_clientemail)){
        $clientemail_err = "Please enter an address.";     
    } else{
        $clientemail = $input_clientemail;
    }

    // Validate address
    $input_phoneno = trim($_POST["phoneno"]);
    if(empty($input_phoneno)){
        $phoneno_err = "Please enter an address.";     
    } else{
        $phoneno = $input_phoneno;
    }

    // Validate address
    $input_bloodgroup = trim($_POST["bloodgroup"]);
    if(empty($input_bloodgroup)){
        $bloodgroup_err = "Please enter an address.";     
    } else{
        $bloodgroup = $input_bloodgroup;
    }

    // Validate address
    $input_address = trim($_POST["address"]);
    if(empty($input_address)){
        $address_err = "Please enter an address.";     
    } else{
        $address = $input_address;
    }

    // Validate address
    $input_dob = trim($_POST["dob"]);
    if(empty($input_dob)){
        $dob_err = "Please enter an address.";     
    } else{
        $dob = $input_dob;
    }

    // Validate address
    $input_age = trim($_POST["age"]);
    if(empty($input_age)){
        $age_err = "Please enter an address.";     
    } else{
        $age = $input_age;
    }

    // Validate address
    $input_allergy = trim($_POST["allergy"]);
    if(empty($input_allergy)){
        $allergy_err = "Please enter an address.";     
    } else{
        $allergy = $input_allergy;
    }
    
      
    // Check input errors before inserting in database
    if(empty($clientname_err) && empty($clientpassword_err) && empty($clientemail_err) && empty($phoneno_err) && empty($bloodgroup_err) && empty($address_err) && empty($dob_err) && empty($age_err) && empty($allergy_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO clientlogin (clientname, clientpassword, clientemail, phoneno, bloodgroup, address, dob, age, allergy) VALUES (:clientname, :clientpassword, :clientemail, :phoneno, :bloodgroup, :address, :dob, :age, :allergy)";
 
        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":clientname", $param_clientname);
            $stmt->bindParam(":clientpassword", $param_clientpassword);
            $stmt->bindParam(":clientemail", $param_clientemail);
            $stmt->bindParam(":phoneno", $param_phoneno);
            $stmt->bindParam(":bloodgroup", $param_bloodgroup);
            $stmt->bindParam(":address", $param_address);
            $stmt->bindParam(":dob", $param_dob);
            $stmt->bindParam(":age", $param_age);
            $stmt->bindParam(":allergy", $param_allergy);
            
            // Set parameters
            $param_clientname = $clientname;
            $param_clientpassword = $clientpassword;
            $param_clientemail = $clientemail;
            $param_phoneno = $phoneno;
            $param_bloodgroup = $bloodgroup;
            $param_address = $address;
            $param_dob = $dob;
            $param_age = $age;
            $param_allergy = $allergy;
            
            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        unset($stmt);
    }
    
    // Close connection
    unset($pdo);
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
     <meta charset="utf-8"/>
    <title>Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="mt-5">Create Record</h2>
                    <p>Please fill this form and submit to add employee record to the database.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        
                        <div class="form-group">
                            <label>clientname</label>
                            <input type="text" name="clientname" class="form-control <?php echo (!empty($clientname_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $clientname; ?>">
                            <span class="invalid-feedback"><?php echo $clientname_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>clientpassword</label>
                            <textarea name="clientpassword" class="form-control <?php echo (!empty($clientpassword_err)) ? 'is-invalid' : ''; ?>"><?php echo $clientpassword; ?></textarea>
                            <span class="invalid-feedback"><?php echo $clientpassword_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>clientemail</label>
                            <input type="text" name="clientemail" class="form-control <?php echo (!empty($clientemail_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $clientemail; ?>">
                            <span class="invalid-feedback"><?php echo $clientemail_err;?></span>
                        </div>

                         <div class="form-group">
                            <label>phoneno</label>
                            <input type="text" name="phoneno" class="form-control <?php echo (!empty($phoneno_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $phoneno; ?>">
                            <span class="invalid-feedback"><?php echo $phoneno_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>bloodgroup</label>
                            <textarea name="bloodgroup" class="form-control <?php echo (!empty($bloodgroup_err)) ? 'is-invalid' : ''; ?>"><?php echo $bloodgroup; ?></textarea>
                            <span class="invalid-feedback"><?php echo $bloodgroup_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>address</label>
                            <input type="text" name="address" class="form-control <?php echo (!empty($address_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $address; ?>">
                            <span class="invalid-feedback"><?php echo $address_err;?></span>
                        </div>

                         <div class="form-group">
                            <label>dob</label>
                            <input type="date" name="dob" class="form-control <?php echo (!empty($dob_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $dob; ?>">
                            <span class="invalid-feedback"><?php echo $dob_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>age</label>
                            <textarea name="age" class="form-control <?php echo (!empty($age_err)) ? 'is-invalid' : ''; ?>"><?php echo $age; ?></textarea>
                            <span class="invalid-feedback"><?php echo $age_err;?></span>
                        </div>

                        <div class="form-group">
                            <label>allergy</label>
                            <input type="text" name="allergy" class="form-control <?php echo (!empty($allergy_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $allergy; ?>">
                            <span class="invalid-feedback"><?php echo $allergy_err;?></span>
                        </div>

                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-secondary ml-2">Cancel</a>
                    </form>
<div class="row  text-center my-5">
    <div class="col"> 
    <a href="../index.html" class="btn btn-primary">Go Back Home</a>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
                    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
                    crossorigin="anonymous"></script>
                <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
                    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
                    crossorigin="anonymous"></script>
                <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
                    integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
                    crossorigin="anonymous"></script>
</body>
</html>
