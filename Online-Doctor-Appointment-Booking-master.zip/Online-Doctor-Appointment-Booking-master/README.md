# Online-Doctor-Appointment-Booking
This Project is written in HTML,CSS and PHP. From this website a client or patient can book their appointment online . Doctors can manage appoint scheduling,reporting etc. While Laboratory can send their report directly to client
