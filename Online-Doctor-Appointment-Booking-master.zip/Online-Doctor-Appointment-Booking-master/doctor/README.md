# Create a Registration and Login System with PHP and MySQL
Create a Registration and Login System with PHP and MySQL

Article: https://speedysense.com/create-registration-login-system-php-mysql
